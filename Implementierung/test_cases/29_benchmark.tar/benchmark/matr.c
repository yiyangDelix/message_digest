
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

static inline double curtime(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

double compute(size_t dim, long a[dim][dim], long b[dim][dim], long c[dim][dim],
        size_t iterations) {

    double time = 0;
    for (size_t n = 0; n < iterations; n++) {
        for (int j = 0; j < dim; j++) {
            for (int i = 0; i < dim; i++) {
                printf("\rProcessing element %d,%d...", i, j);
                double start = curtime();
                c[i][j] = a[i][j] * b[i][j];
                double end = curtime();
                time += end - start;
            }
        }
    }

    return time;
}

void init(size_t dim, long a[dim][dim], long b[dim][dim], long c[dim][dim]) {
    for (int j = 0; j < dim; j++)
        for (int i = 0; i < dim; i++)
            a[i][j] = b[i][j] = i * dim + j;
}

static bool parse_ul(const char* str, unsigned long* out) {
    errno = 0;
    char* endptr;

    *out = strtoul(str, &endptr, 0);
    if (endptr == str || *endptr != '\0') {
        fprintf(stderr, "'%s' could not be converted to a long.\n", str);
        return false;
    } else if (errno == ERANGE || errno == EINVAL) {
        fprintf(stderr, "Failed to convert '%s' to long. Maybe under- or overflowed.\n", str);
        return false;
    }

    return true;
}

int main(int argc, char** argv) {
    setbuf(stdout, NULL);
    size_t problem_size = 512;
    size_t iterations = 10;

    // Parse command line arguments. Refer to man page for details:
    // $ man 3 getopt
    int opt;
    while ((opt = getopt(argc, argv, "p:i:")) != -1) {
        switch (opt) {
        case 'p': {
            if (!parse_ul(optarg, &problem_size)) {
                exit(EXIT_FAILURE);
            }
            break;
        }
        case 'i': {
            if (!parse_ul(optarg, &iterations)) {
                exit(EXIT_FAILURE);
            }
            break;
        }
        default:
            fprintf(stderr, "usage: %s [-p problem_size] [-i iterations]\n", argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    void* a = malloc(problem_size * problem_size * sizeof(long));
    void* b = malloc(problem_size * problem_size * sizeof(long));
    void* c = calloc(problem_size * problem_size, sizeof(long));

    init(problem_size, a, b, c);

    double time = compute(problem_size, a, b, c, iterations);
    printf("Took %f seconds\n", time);

    free(a);
    free(b);
    free(c);

    return 0;
}
